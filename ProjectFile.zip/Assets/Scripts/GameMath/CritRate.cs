using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CritRate : MonoBehaviour
{
    public TextMeshProUGUI critTMP;
    float critRate = 0.1f;

    private int totalCrit;
    private int totalAttack;
    private bool pastCrit = false;
    
    // Start is called before the first frame update
    public void TryHit()
    {
        totalAttack++;

        float currentRate = totalCrit / (float)totalAttack;

        bool isCritical;

        //���� ����
        if (pastCrit = true && currentRate < critRate)
        {
            //������ �߻�
            isCritical = true;
        }
        else if (pastCrit = false && critRate > currentRate)
        {
            //������ ����
            isCritical = false;
        }
        else
        {
            //�������� ũ��Ƽ��
            isCritical = Random.value < critRate;
        }
        if (isCritical)
        {
            pastCrit = true;
            totalCrit++;
        }
        else
        {
            pastCrit = false;
        }


        float actualCrit = (totalCrit == 0) ? 0f : (float)totalCrit / totalAttack;
        critTMP.text = $"ġ��Ÿ: {totalCrit}| ��ü ����: {totalAttack} | ġ��Ÿ��: {actualCrit*100f:F2}% {critRate},{currentRate}";

    }
}
